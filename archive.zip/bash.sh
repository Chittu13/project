#!/bin/bash

echo "[*] Compiling web scanner..."
g++ modules/webscanner.cpp -o modules/webscanner -lcurl

if [ $? -eq 0 ]; then
    echo "[+] Compilation successful! Running scanner..."
    ./modules/webscanner
else
    echo "[!] Compilation failed."
fi

