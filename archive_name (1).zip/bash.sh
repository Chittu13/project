#!/bin/bash

echo "[*] Compiling web scanner..."
g++ modules/endpoint.cpp -o modules/endpoint -lcurl

if [ $? -eq 0 ]; then
    echo "[+] Compilation successful! Running scanner..."
    ./modules/endpoint
else
    echo "[!] Compilation failed."
fi

